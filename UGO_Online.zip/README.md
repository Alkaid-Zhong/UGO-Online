# UGO_Online



## 启动方式

项目后端已经部署到云服务器，因此只需启动前端即可。可直接访问：http://8.152.218.70/

1. 项目启动方法：

```shell
# 配置前端环境
npm install
npm run dev
```

2. 访问地址 http://localhost:3000/
